#define HAVE_WINDOWS_H
//#define HAVE_DIRENT_H
#define HAVE_FCNTL_H
#define BINDIR80 getenv("ZXBINDIR")
#define LIBDIR80 getenv("ZXLIBDIR")
#define INCDIR80 getenv("ZXINCDIR")
#define WIN32
#define WINVER 0x0501		// target Windows XP
#define _WIN32_WINNNT 0x0501	// target Windows XP
