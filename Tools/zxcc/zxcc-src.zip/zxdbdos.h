


int fcbforce(byte *fcb, byte *odrv);

word x_fcb_open(byte *fcb, byte *dma);
word x_fcb_stat(byte *fcb);

