void bdos_rdline(word line, word *PC);
int cpm_bdos_6(byte e);


